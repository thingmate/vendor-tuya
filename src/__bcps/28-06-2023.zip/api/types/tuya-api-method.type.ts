export type ITuyaApiMethod =
  | 'GET'
  | 'PUT'
  | 'POST'
  | 'DELETE'
  ;
