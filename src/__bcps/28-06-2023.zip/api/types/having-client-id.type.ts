export interface IHavingClientId {
  clientId: string;
}
