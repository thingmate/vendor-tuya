export interface IHavingNonce {
  nonce: string;
}
