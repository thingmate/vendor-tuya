export interface IHavingClientSecret {
  clientSecret: string;
}
