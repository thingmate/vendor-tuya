export interface ITuyaAccessTokenJSON {
  access_token: string;
  expire_time: number;
  refresh_token: string;
  uid: string;
}

