export interface ITuyaDeviceStatusJSON {
  code: string;
  value: any;
}
