export type ITuyaDeviceStatusMap = Map<string, any>;
