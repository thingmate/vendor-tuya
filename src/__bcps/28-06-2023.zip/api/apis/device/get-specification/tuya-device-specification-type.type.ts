export type ITuyaDeviceSpecificationType =
  | 'Boolean'
  | 'Integer'
  | 'Json'
  | 'Enum'
  ;
