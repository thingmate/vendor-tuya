import { Abortable } from '@lirx/async-task';
import { sleep } from '@lirx/promise';
import { IForgeWebSocketUrlFunction } from '@thingmate/vendor-meross/src/device/init-meross-mqtt-client';
import { getWebSocketProxyUrl } from '../../misc/get-web-socket-proxy-url';
import { TUYA_CONFIG } from '../configs/tuya/tuya-config.private';
import { getTuyaDeviceList, ITuyaDeviceListResponseJSON } from './api/get-tuya-device-list';
import { getTuyaDeviceState } from './api/get-tuya-device-state';
import { ITuyaLoginResponseJSON } from './api/perform-tuya-login';
import { setTuyaDeviceState } from './api/set-tuya-device-state';

/*--------------------*/

function getLoginResponse(): ITuyaLoginResponseJSON {
  return {
    access_token: 'EUheu1554304258632qrMDFRJH1dVMTCL',
    expires_in: 864000,
    refresh_token: 'EUheu1554304258632qrMDFOmLx9toHtf',
    token_type: 'bearer',
  };
}

function getDevices(): ITuyaDeviceListResponseJSON {
  return {
    'devices': [
      {
        'data': {
          'online': false,
          'state': false,
        },
        'name': 'prise 2',
        'icon': 'https://images.tuyaeu.com/smart/icon/15326787153o14hnl5jq_0.jpg',
        'id': '05200313ecfabc18deef',
        'dev_type': 'switch',
        'ha_type': 'switch',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': false,
          'state': 'false',
          'color_temp': 4600,
        },
        'name': 'lumière 2',
        'icon': 'https://images.tuyaeu.com/smart/icon/dj.png',
        'id': '1382120084f3eb76cb3c',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'online': true,
          'state': false,
        },
        'name': 'Prise 1',
        'icon': 'https://images.tuyaeu.com/smart/icon/15326787153o14hnl5jq_0.jpg',
        'id': '12036503807d3a3c37b3',
        'dev_type': 'switch',
        'ha_type': 'switch',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': false,
          'state': 'false',
          'color_temp': 4635,
        },
        'name': 'lumière 3',
        'icon': 'https://images.tuyaeu.com/smart/icon/dj.png',
        'id': '01734776cc50e3cb26a8',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': false,
          'state': 'false',
          'color_temp': 4600,
        },
        'name': 'lumière 1',
        'icon': 'https://images.tuyaeu.com/smart/icon/dj.png',
        'id': '44641180ecfabc2d7f0f',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': true,
          'state': 'false',
          'color_temp': 4600,
        },
        'name': 'lumière 9',
        'icon': 'https://images.tuyaeu.com/smart/product_icon/dj.png',
        'id': '066544008caab50061f8',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': false,
          'state': 'false',
          'color_temp': 4600,
        },
        'name': 'lumière 7',
        'icon': 'https://images.tuyaeu.com/smart/icon/ay15027809538862HzJ4/1608955474702db0a867f.png',
        'id': '3840410598f4abb77ba3',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': false,
          'state': 'false',
          'color_temp': 4600,
        },
        'name': 'lumière 6',
        'icon': 'https://images.tuyaeu.com/smart/icon/ay15027809538862HzJ4/1608955474702db0a867f.png',
        'id': '38404105ecfabc674370',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': false,
          'state': 'false',
          'color_temp': 4635,
        },
        'name': 'lumière 4',
        'icon': 'https://images.tuyaeu.com/smart/icon/dj.png',
        'id': '01734776cc50e3cb211e',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': false,
          'state': 'false',
          'color_temp': 4600,
        },
        'name': 'lumière 5',
        'icon': 'https://images.tuyaeu.com/smart/icon/ay15027809538862HzJ4/1608955474702db0a867f.png',
        'id': '38404105a4cf12cd6c28',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': true,
          'state': 'false',
          'color_temp': 4600,
        },
        'name': 'lumière 10',
        'icon': 'https://images.tuyaeu.com/smart/product_icon/dj.png',
        'id': '30044711bcddc26965b6',
        'dev_type': 'light',
        'ha_type': 'light',
      },
      {
        'data': {
          'brightness': '255',
          'color_mode': 'white',
          'online': false,
          'state': 'false',
          'color_temp': 4600,
        },
        'name': 'lumière 8',
        'icon': 'https://images.tuyaeu.com/smart/icon/ay15027809538862HzJ4/1608955474702db0a867f.png',
        'id': '38404105a4cf12cd69c5',
        'dev_type': 'light',
        'ha_type': 'light',
      },
    ],
    'scenes': [],
  };
}

/*--------------------*/

const forgeWebSocketUrlFunction: IForgeWebSocketUrlFunction = (url: URL): URL => {
  return getWebSocketProxyUrl({
    hostname: url.hostname,
    port: Number(url.port),
    protocol: 'mqtt',
  });
};

/*--------------------*/

// https://github.com/milo526/homebridge-tuya-web/tree/master/src/api

/*--------------------*/

async function debugTuya01() {
  const abortable = Abortable.never;

  const CONFIG = TUYA_CONFIG;

  const region = 'eu';

  // const loginResponse = await performTuyaLogin({
  //   ...CONFIG,
  //   region,
  //   countryCode: '33',
  //   bizType: 'smart_life',
  //   abortable,
  // }).toPromise();

  const loginResponse: ITuyaLoginResponseJSON = getLoginResponse();

  // console.log(loginResponse);

  // const devices = await getTuyaDeviceList({
  //   ...CONFIG,
  //   region,
  //   token: loginResponse.access_token,
  //   abortable,
  // }).toPromise();
  //
  // console.log(devices);

  const devices = getDevices();

    // const deviceId = '05200313ecfabc18deef'; // switch
  const deviceId = '30044711bcddc26965b6'; // light

  const state = await getTuyaDeviceState({
    ...CONFIG,
    region,
    token: loginResponse.access_token,
    deviceId,
    abortable,
  }).toPromise();

  console.log(state);


  // await setTuyaDeviceState({
  //   ...CONFIG,
  //   region,
  //   token: loginResponse.access_token,
  //   deviceId,
  //   command: 'turnOnOff',
  //   payload: {
  //     value: 0,
  //   },
  //   abortable,
  // }).toPromise();
  //
  // await sleep(3000);
  //
  // await setTuyaDeviceState({
  //   ...CONFIG,
  //   region,
  //   token: loginResponse.access_token,
  //   deviceId,
  //   command: 'colorSet',
  //   payload: {
  //     hue: 0,
  //     saturation: 100,
  //     brightness: 255,
  //   },
  //   abortable,
  // }).toPromise();
}

/*--------------------*/

export async function debugTuya() {
  await debugTuya01();
}
