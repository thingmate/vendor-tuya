import { AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { fetchTuyaApi } from './helpers/fetch/fetch-tuya-api';
import { generateFetchTuyaApiData } from './helpers/fetch/generate-fetch-tuya-api-data';
import { getTuyaSkillUrl } from './helpers/urls/get-tuya-skill-url';
import { IHavingTuyaToken } from './types/having-tuya-token.type';
import { ITuyaDeviceData } from './types/tuya-device';
import { IHavingTuyaRegion } from './types/tuya-region.type';

/** OPTIONS **/

/* SHARED */

export interface ISetTuyaDeviceStateOptionsShared extends IHavingTuyaRegion, IHavingTuyaToken, IAbortableOptions {
  deviceId: string;
}

export interface ISetTuyaDeviceStateOptionsBuilder<GCommand extends string, GPayload> extends ISetTuyaDeviceStateOptionsShared {
  command: GCommand;
  payload: GPayload;
}

/* turnOnOff */

export interface ISetTuyaDeviceTurnOnOffStateOptionsPayload {
  value: 0 | 1;
}

export type ISetTuyaDeviceTurnOnOffStateOptions = ISetTuyaDeviceStateOptionsBuilder<'turnOnOff', ISetTuyaDeviceTurnOnOffStateOptionsPayload>;


/* colorSet */

export interface ISetTuyaDeviceColorSetStateOptionsPayload {
  hue: number;
  saturation: number; // [0, 1]
  brightness: number; // [0, 255]
}

export type ISetTuyaDeviceColorSetStateOptions = ISetTuyaDeviceStateOptionsBuilder<'colorSet', ISetTuyaDeviceColorSetStateOptionsPayload>;


/* ALL */

export type ISetTuyaDeviceStateOptions =
  | ISetTuyaDeviceTurnOnOffStateOptions
  | ISetTuyaDeviceColorSetStateOptions
  ;

/** RESPONSE **/

export interface ITuyaDeviceStateResponseJSON {
}

// export type ISetTuyaDeviceStateCommand =
//   | 'brightnessSet'
//   | 'colorSet'
//   | 'colorTemperatureSet'
//   | 'modeSet'
//   | 'startStop'
//   | 'temperatureSet'
//   | 'turnOnOff'
//   | 'windSpeedSet'
//   ;
//
// export type TuyaApiPayload<Method extends ISetTuyaDeviceStateCommand> =
//   Method extends 'brightnessSet'
//     ? { value: number }
//     : Method extends 'colorSet'
//       ? { color: { hue: number; saturation: number; brightness: number } }
//       : Method extends 'colorTemperatureSet'
//         ? { value: number }
//         : Method extends 'modeSet'
//           ? { value: any } // { value: ClimateMode }
//           : Method extends 'startStop'
//             ? { value: 0 }
//             : Method extends 'temperatureSet'
//               ? { value: number }
//               : Method extends 'turnOnOff'
//                 ? { value: 0 | 1 }
//                 : Method extends 'windSpeedSet'
//                   ? { value: number }
//                   : never;

/** FETCH API **/

export function setTuyaDeviceState(
  {
    region,
    token,
    deviceId,
    command,
    payload,
    abortable,
  }: ISetTuyaDeviceStateOptions,
): AsyncTask<ITuyaDeviceStateResponseJSON> {
  return fetchTuyaApi<ITuyaDeviceStateResponseJSON>({
    url: getTuyaSkillUrl(region),
    method: 'POST',
    data: generateFetchTuyaApiData({
      token,
      command,
      namespace: 'control',
      payload: {
        ...payload,
        devId: deviceId,
      },
    }),
    abortable,
  });
}
