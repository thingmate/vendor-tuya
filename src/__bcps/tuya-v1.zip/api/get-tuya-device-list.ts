import { AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { fetchTuyaApi } from './helpers/fetch/fetch-tuya-api';
import { generateFetchTuyaApiData } from './helpers/fetch/generate-fetch-tuya-api-data';
import { getTuyaSkillUrl } from './helpers/urls/get-tuya-skill-url';
import { IHavingTuyaToken } from './types/having-tuya-token.type';
import { ITuyaDevice } from './types/tuya-device';
import { IHavingTuyaRegion } from './types/tuya-region.type';



/** LIST DEVICES **/

export interface ITuyaDeviceListResponseJSON {
  devices: ITuyaDevice[];
  scenes: unknown[];
}

export interface IGetTuyaDeviceListOptions extends IHavingTuyaRegion, IHavingTuyaToken, IAbortableOptions {
}

export function getTuyaDeviceList(
  {
    region,
    token,
    abortable,
  }: IGetTuyaDeviceListOptions,
): AsyncTask<ITuyaDeviceListResponseJSON> {
  return fetchTuyaApi<ITuyaDeviceListResponseJSON>({
    url: getTuyaSkillUrl(region),
    method: 'GET',
    data: generateFetchTuyaApiData({
      token,
      command: 'Discovery',
      namespace: 'discovery',
    }),
    abortable,
  });
}
