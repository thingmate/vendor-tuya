import { AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { fetchTuyaApi } from './helpers/fetch/fetch-tuya-api';
import { generateFetchTuyaApiData } from './helpers/fetch/generate-fetch-tuya-api-data';
import { getTuyaSkillUrl } from './helpers/urls/get-tuya-skill-url';
import { IHavingTuyaToken } from './types/having-tuya-token.type';
import { ITuyaDeviceData } from './types/tuya-device';
import { IHavingTuyaRegion } from './types/tuya-region.type';


export interface ITuyaDeviceStateResponseJSON<GData extends ITuyaDeviceData> {
  data: GData;
}

export interface IGetTuyaDeviceStateOptions extends IHavingTuyaRegion, IHavingTuyaToken, IAbortableOptions {
  deviceId: string;
}

export function getTuyaDeviceState<GData extends ITuyaDeviceData>(
  {
    region,
    token,
    deviceId,
    abortable,
  }: IGetTuyaDeviceStateOptions,
): AsyncTask<ITuyaDeviceStateResponseJSON<GData>> {
  return fetchTuyaApi<ITuyaDeviceStateResponseJSON<GData>>({
    url: getTuyaSkillUrl(region),
    method: 'GET',
    data: generateFetchTuyaApiData({
      token,
      command: 'QueryDevice',
      namespace: 'query',
      payload: {
        devId: deviceId,
        value: 1,
      },
    }),
    abortable,
  });
}
