import { asyncFetchJSON, AsyncTask, IAbortableOptions } from '@lirx/async-task';
import { getTuyaUrl } from './helpers/urls/get-tuya-url';
import { IHavingTuyaRegion } from './types/tuya-region.type';

export interface ITuyaLoginResponseJSON {
  access_token: string;
  expires_in: number; // usually 10 days
  refresh_token: string;
  token_type: 'bearer';
}

export interface IPerformTuyaLoginOptions extends IHavingTuyaRegion, IAbortableOptions {
  email: string;
  password: string;
  countryCode: string;
  bizType?: 'tuya' | 'smart_life';
}

export function performTuyaLogin(
  {
    region,
    email,
    password,
    countryCode,
    bizType = 'smart_life',
    abortable,
  }: IPerformTuyaLoginOptions,
): AsyncTask<ITuyaLoginResponseJSON> {
  const url = `${getTuyaUrl(region)}/auth.do`;

  const headers = new Headers({
    'Content-Type': 'application/x-www-form-urlencoded',
  });

  const body = new URLSearchParams({
    'userName': email,
    'password': password,
    'countryCode': countryCode,
    'bizType': bizType,
    'from': 'tuya',
  });

  const request = new Request(url, {
    method: 'POST',
    headers,
    body,
  });

  return asyncFetchJSON<ITuyaLoginResponseJSON>(
    request,
    void 0,
    abortable,
  );
}



