export type ITuyaRegion =
  | 'az' // Americas
  | 'eu' // Europe
  | 'ay' // Asia
  | 'us' // United States
  ;

export interface IHavingTuyaRegion {
  region: ITuyaRegion;
}
