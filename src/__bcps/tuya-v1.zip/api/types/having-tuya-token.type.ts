
export interface IHavingTuyaToken {
  token: string;
}
