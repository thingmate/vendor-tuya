/** DEVICES **/

/* SHARED */

export interface ITuyaDeviceBuilder<GType extends string, GData> {
  data: GData;
  name: string;
  icon: string;
  id: string;
  dev_type: GType;
  ha_type: GType;
}

export type ITuyaDeviceGeneric = ITuyaDeviceBuilder<string, object>;

export interface ITuyaDeviceDataHavingOnline {
  online: boolean;
}

/* SWITCH */

export interface ITuyaDeviceSwitchData extends ITuyaDeviceDataHavingOnline {
  state: boolean;
}

export type ITuyaDeviceSwitch = ITuyaDeviceBuilder<'switch', ITuyaDeviceSwitchData>;

export function isTuyaSwitchDevice(
  value: ITuyaDeviceGeneric,
): value is ITuyaDeviceSwitch {
  return value.dev_type === 'switch';
}

/* LIGHT */

export interface ITuyaDeviceLightData extends ITuyaDeviceDataHavingOnline {
  brightness: string; // from 0 to 255
  color_mode: 'white' | 'colour';
  state: 'false' | 'true';
  color_temp: number;
}

export type ITuyaDeviceLight = ITuyaDeviceBuilder<'light', ITuyaDeviceLightData>;

export function isTuyaLightDevice(
  value: ITuyaDeviceGeneric,
): value is ITuyaDeviceLight {
  return value.dev_type === 'light';
}

/* ALL */

export type ITuyaDevice =
  | ITuyaDeviceSwitch
  | ITuyaDeviceLight
  ;

export type ITuyaDeviceData =
  | ITuyaDeviceSwitchData
  | ITuyaDeviceLightData
  ;
