import { asyncFetchJSON, AsyncTask, IAbortableOptions, IAsyncTaskConstraint } from '@lirx/async-task';

export interface IFetchTuyaAPIRequestHeaderJSON {
  name: string;
  namespace: string;
  payloadVersion: 1;
}

export type IFetchTuyaAPIRequestPayloadJSON<GPayload> = GPayload & {
  accessToken: string;
}

export interface IFetchTuyaAPIRequestDataJSON<GPayload> {
  header: IFetchTuyaAPIRequestHeaderJSON;
  payload: IFetchTuyaAPIRequestPayloadJSON<GPayload>;
}

export interface IFetchTuyaAPIOptions extends IAbortableOptions {
  url: URL | string;
  method: 'GET' | 'POST';
  data: IFetchTuyaAPIRequestDataJSON<Record<string, any>>;
}

export type IFetchTuyaAPIResponseHeaderCode =
  | 'SUCCESS'
  | 'FrequentlyInvoke'
  | 'TargetOffline'
  | 'UnsupportedOperation'
  | 'DependentServiceUnavailable'
  | string
  ;

export interface IFetchTuyaAPIResponseHeaderJSON {
  code: IFetchTuyaAPIResponseHeaderCode;
  msg?: string;
  payloadVersion: 1;
}

export interface IFetchTuyaAPIResponseJSON<GPayload> {
  header: IFetchTuyaAPIResponseHeaderJSON;
  payload: GPayload;
}

export function fetchTuyaApi<GPayload extends IAsyncTaskConstraint<GPayload>>(
  {
    url,
    data,
    abortable,
  }: IFetchTuyaAPIOptions,
): AsyncTask<GPayload> {
  const headers = new Headers({
    'Content-Type': 'application/json',
  });

  const body = JSON.stringify(data);

  const request = new Request(url, {
    method: 'POST',
    headers,
    body,
  });

  return asyncFetchJSON<IFetchTuyaAPIResponseJSON<GPayload>>(
    request,
    void 0,
    abortable,
  )
    .successful((
      result: IFetchTuyaAPIResponseJSON<GPayload>,
    ): GPayload => {
      switch (result.header.code) {
        case 'SUCCESS':
          return result.payload;
        case 'FrequentlyInvoke':
          throw new Error(`Rate limit reached: ${result.header.msg}`);
        case 'TargetOffline':
          throw new Error(`The device is offline: ${result.header.msg}`);
        case 'UnsupportedOperation':
          throw new Error(`The device does not support this operation: ${result.header.msg}`);
        case 'DependentServiceUnavailable':
          throw new Error(`This operation requires to perform another operation before: ${result.header.msg}`);
        default:
          throw new Error(`${result.header.code}`);
      }
    });
}
