import { IHavingTuyaToken } from '../../types/having-tuya-token.type';
import { IFetchTuyaAPIRequestDataJSON, IFetchTuyaAPIRequestPayloadJSON } from './fetch-tuya-api';

export interface IGenerateFetchTuyaApiDataOptions<GPayload> extends IHavingTuyaToken {
  command: string;
  namespace: string;
  payload?: GPayload;
}

export function generateFetchTuyaApiData<GPayload>(
  {
    token,
    command,
    namespace,
    payload,
  }: IGenerateFetchTuyaApiDataOptions<GPayload>,
): IFetchTuyaAPIRequestDataJSON<GPayload> {
  return {
    header: {
      name: command,
      namespace,
      payloadVersion: 1,
    },
    payload: {
      ...payload,
      accessToken: token,
    } as IFetchTuyaAPIRequestPayloadJSON<GPayload>,
  };
}
