import { getTuyaUrl } from './get-tuya-url';
import { ITuyaRegion } from '../../types/tuya-region.type';

export function getTuyaSkillUrl(
  region: ITuyaRegion,
): string {
  return `${getTuyaUrl(region)}/skill`;
}
