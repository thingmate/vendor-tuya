import { ITuyaRegion } from '../../types/tuya-region.type';

export function getTuyaUrl(
  region: ITuyaRegion,
): string {
  return `https://px1.tuya${region}.com/homeassistant`;
}
