import { Abortable, AsyncTask, IAsyncTaskFactory, IAsyncTaskInput } from '@lirx/async-task';
import { AsyncValueObserverFactory, IThingDiscovery, Thing } from '@thingmate/wot-scripting-api';
import {
  AsyncValueObserver
} from '@thingmate/wot-scripting-api/src/async-value/methods/observer/async-value-observer/async-value-observer.class';
import { IThingDescription } from '@thingmate/wot-scripting-api/src/thing/thing.class';
import { ITuyaDeviceDetailsJSON } from '../../api/apis/device/get-details/types/tuya-device-details-json.type';
import { getTuyaDeviceList } from '../../api/apis/device/get-device-list/get-tuya-devices-list';
import { ITuyaDeviceListJSON } from '../../api/apis/device/get-device-list/types/tuya-device-list-json.type';
import { ITuyaDeviceCategory } from '../../api/apis/device/types/tuya-device-category.type';
import {
  createTuyaApiContext,
  ICreateTuyaApiContextOptions,
  ITuyaApiContext,
  ITuyaApiContextFactoryOptions,
} from '../../api/helpers/create-tuya-api-context';
import { createTuyaSmartLightThing } from '../things/smart-light/create-tuya-smart-light-thing';
import { createTuyaSmartPlugThing } from '../things/smart-plug/create-tuya-smart-plug-thing';

export interface ITuyaThingDiscoveryOptions extends ICreateTuyaApiContextOptions {
  tuyaUserId: string;
  showOffLine?: boolean;
}

export interface ITuyaThingDescription extends IThingDescription {
  id: string;
  deviceType: ITuyaDeviceCategory;
  isOnline: boolean;
}

export type ITuyaThing = Thing<ITuyaThingDescription, any>;

export type ITuyaThingDiscovery = IThingDiscovery<ITuyaThing>;

export function createTuyaThingDiscovery(
  {
    tuyaUserId,
    showOffLine = false,
    ...options
  }: ITuyaThingDiscoveryOptions,
): ITuyaThingDiscovery {
  const tuyaApiContext: ITuyaApiContext = createTuyaApiContext(options);

  const getTuyaThings = (
    abortable: Abortable,
  ): AsyncTask<ITuyaThing[]> => {
    return tuyaApiContext((options: ITuyaApiContextFactoryOptions): AsyncTask<ITuyaDeviceListJSON> => {
      return getTuyaDeviceList({
        ...options,
        sourceType: 'tuyaUser',
        sourceId: tuyaUserId,
      });
    }, abortable)
      .successful((list: ITuyaDeviceListJSON, abortable: Abortable): ITuyaThing[] => {
        return list.list
          .map((device: ITuyaDeviceDetailsJSON): ITuyaThing | null => {
            if (device.online || showOffLine) {
              const description: ITuyaThingDescription = {
                id: device.uuid,
                title: device.name,
                deviceType: device.category,
                isOnline: device.online,
              };

              const options = {
                description,
                context: tuyaApiContext,
                deviceId: device.id,
              };

              switch (device.category) {
                case 'cz':
                  return createTuyaSmartPlugThing<ITuyaThingDescription>(options);
                case 'dj':
                  return createTuyaSmartLightThing<ITuyaThingDescription>(options);
                default:
                  console.error(new Error(`Unsupported type: ${device.category}`));
                  return null;

              }
            } else {
              return null;
            }
          })
          .filter<ITuyaThing>((thing: ITuyaThing | null): thing is ITuyaThing => {
            return thing !== null;
          });
      });
  };

  return new AsyncValueObserverFactory<ITuyaThing>({
    start: (
      abortable: Abortable,
    ): IAsyncTaskInput<AsyncValueObserver<ITuyaThing>> => {
      return new AsyncValueObserver<ITuyaThing>({
        value$:
      });
    },
  });

  // return ThingDiscovery.fromAsyncTaskFactoryIterator((function* (): Generator<IAsyncTaskFactory<IDiscoverFunctionResult<ITuyaThing>>> {
  //   const things = getTuyaThings(Abortable.never);
  //
  //   let index: number = 0;
  //   while (true) {
  //     yield (abortable: Abortable): AsyncTask<IDiscoverFunctionResult<ITuyaThing>> => {
  //       return things
  //         .switchAbortable(abortable)
  //         .successful((things: ITuyaThing[]): IDiscoverFunctionResult<ITuyaThing> => {
  //           if (index < things.length) {
  //             return {
  //               done: false,
  //               value: things[index++],
  //             };
  //           } else {
  //             return DISCOVER_FUNCTION_DONE_RESULT;
  //           }
  //         });
  //     };
  //   }
  // })());

  // let deviceList: AsyncTask<ITuyaThing[]>;
  // let index: number = -1;
  //
  // const discover = (
  //   abortable: Abortable,
  // ): IPushSourceWithBackPressure<ITuyaThing> => {
  //   if (deviceList === void 0) {
  //     deviceList = tuyaApiContext((options: ITuyaApiContextFactoryOptions): AsyncTask<ITuyaDeviceListJSON> => {
  //       return getTuyaDeviceList({
  //         ...options,
  //         sourceType: 'tuyaUser',
  //         sourceId: tuyaUserId,
  //       });
  //     }, Abortable.never)
  //       .successful((list: ITuyaDeviceListJSON, abortable: Abortable): ITuyaThing[] => {
  //         return list.list
  //           .map((device: ITuyaDeviceDetailsJSON): ITuyaThing | null => {
  //             if (device.online || showOffLine) {
  //               const description: ITuyaThingDescription = {
  //                 id: device.uuid,
  //                 title: device.name,
  //                 deviceType: device.category,
  //                 isOnline: device.online,
  //               };
  //
  //               const options = {
  //                 description,
  //                 context: tuyaApiContext,
  //                 deviceId: device.id,
  //               };
  //
  //               switch (device.category) {
  //                 case 'cz':
  //                   return createTuyaSmartPlugThing<ITuyaThingDescription>(options);
  //                 case 'dj':
  //                   return createTuyaSmartLightThing<ITuyaThingDescription>(options);
  //                 default:
  //                   console.error(new Error(`Unsupported type: ${device.category}`));
  //                   return null;
  //
  //               }
  //             } else {
  //               return null;
  //             }
  //           })
  //           .filter<ITuyaThing>((thing: ITuyaThing | null): thing is ITuyaThing => {
  //             return thing !== null;
  //           });
  //       });
  //   }
  //
  //   return deviceList.successful((list: ITuyaDeviceListJSON, abortable: Abortable): ITuyaThing | AsyncTask<ITuyaThing> => {
  //     index++;
  //     if (index < list.list.length) {
  //
  //     }
  //   });
  // };
  //
  // return new ThingDiscovery<IGenericThing>({
  //   discover,
  // });
}
