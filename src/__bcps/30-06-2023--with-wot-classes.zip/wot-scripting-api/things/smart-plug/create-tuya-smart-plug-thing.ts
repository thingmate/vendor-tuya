import { ISmartPlugProperties, ISmartPlugThing, Thing } from '@thingmate/wot-scripting-api';
import { IThingDescription, IThingInitOptions } from '@thingmate/wot-scripting-api/src/thing/thing.class';

import { ICreateTuyaColorThingPropertyOptions } from '../../properties/tuya-color-thing-property/create-tuya-color-thing-property.class';
import {
  createTuyaOnOffThingProperty,
  ICreateTuyaOnOffThingPropertyOptions,
} from '../../properties/tuya-on-off-thing-property/create-tuya-on-off-thing-property';
import {
  createTuyaOnlineThingProperty,
  ICreateTuyaOnlineThingPropertyOptions,
} from '../../properties/tuya-online-thing-property/create-tuya-online-thing-property.class';
import {
  createTuyaConsumptionHistoryThingProperty,
} from '../../properties/tuya-power-consumption-history-thing-property/create-tuya-power-consumption-history-thing-property.class';
import {
  createTuyaConsumptionThingProperty,
} from '../../properties/tuya-power-consumption-thing-property/create-tuya-power-consumption-thing-property.class';

export interface ICreateTuyaSmartPlugThingOptions<GDescription extends IThingDescription> extends //
  ICreateTuyaOnlineThingPropertyOptions,
  Omit<ICreateTuyaOnOffThingPropertyOptions, 'onOffCommand'>,
  ICreateTuyaColorThingPropertyOptions,
  Omit<IThingInitOptions<GDescription, ISmartPlugProperties>, 'properties'>
//
{
  chanel?: number,
}

export function createTuyaSmartPlugThing<GDescription extends IThingDescription>(
  {
    chanel = 0,
    ...options
  }: ICreateTuyaSmartPlugThingOptions<GDescription>,
): ISmartPlugThing<GDescription> {
  return new Thing<GDescription, ISmartPlugProperties>({
    description: options.description,
    properties: {
      online: createTuyaOnlineThingProperty(options),
      onoff: createTuyaOnOffThingProperty({
        ...options,
        onOffCommand: `switch_${chanel + 1}`,
      }),
      consumption: createTuyaConsumptionThingProperty({}),
      consumptionHistory: createTuyaConsumptionHistoryThingProperty({}),
    },
  });
}

