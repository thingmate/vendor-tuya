import { ISmartLightProperties, ISmartLightThing, Thing } from '@thingmate/wot-scripting-api';
import { IThingDescription, IThingInitOptions } from '@thingmate/wot-scripting-api/src/thing/thing.class';
import {
  createTuyaColorThingProperty,
  ICreateTuyaColorThingPropertyOptions,
} from '../../properties/tuya-color-thing-property/create-tuya-color-thing-property.class';
import {
  createTuyaOnOffThingProperty,
  ICreateTuyaOnOffThingPropertyOptions,
} from '../../properties/tuya-on-off-thing-property/create-tuya-on-off-thing-property';
import {
  createTuyaOnlineThingProperty,
  ICreateTuyaOnlineThingPropertyOptions,
} from '../../properties/tuya-online-thing-property/create-tuya-online-thing-property.class';

export interface ITuyaSmartLightThingOptions<GDescription extends IThingDescription> extends //
  ICreateTuyaOnlineThingPropertyOptions,
  Omit<ICreateTuyaOnOffThingPropertyOptions, 'onOffCommand'>,
  ICreateTuyaColorThingPropertyOptions,
  Omit<IThingInitOptions<GDescription, ISmartLightProperties>, 'properties'>
//
{
}

export function createTuyaSmartLightThing<GDescription extends IThingDescription>(
  options: ITuyaSmartLightThingOptions<GDescription>,
): ISmartLightThing<GDescription> {
  return new Thing<GDescription, ISmartLightProperties>({
    description: options.description,
    properties: {
      online: createTuyaOnlineThingProperty(options),
      onoff: createTuyaOnOffThingProperty({
        ...options,
        onOffCommand: 'switch_led',
      }),
      color: createTuyaColorThingProperty(options),
    },
  });
}

