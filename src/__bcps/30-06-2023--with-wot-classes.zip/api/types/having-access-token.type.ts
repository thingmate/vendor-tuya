export interface IHavingAccessToken {
  accessToken: string;
}
