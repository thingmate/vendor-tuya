export interface IHavingTimestamp {
  timestamp: number;
}
