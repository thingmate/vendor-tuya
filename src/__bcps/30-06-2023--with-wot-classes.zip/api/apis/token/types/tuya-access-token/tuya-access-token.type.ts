export interface ITuyaAccessToken{
  accessToken: string;
  refreshToken: string;
  expireDate: number;
}
