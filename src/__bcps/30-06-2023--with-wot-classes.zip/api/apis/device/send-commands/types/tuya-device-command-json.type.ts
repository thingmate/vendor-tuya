export interface ITuyaDeviceCommandJSON {
  code: string;
  value: any;
}
